﻿namespace evaAFPCrecer.Models
{
    public class Empresa
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }

        public string? RazonSocial { get; set; }

        public DateTime FechaRegistro { get; set; }
    }
}
