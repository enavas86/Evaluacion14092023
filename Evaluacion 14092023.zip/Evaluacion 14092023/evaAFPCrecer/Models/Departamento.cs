﻿namespace evaAFPCrecer.Models
{
    public class Departamento
    {
        public int Id { get; set; }

        public int IdEmpresa { get; set; }

        public string? Nombre { get; set; }

        public int NumeroEmpleados { get; set; }

        public int NivelOrganizacion { get; set; }
    }
}
