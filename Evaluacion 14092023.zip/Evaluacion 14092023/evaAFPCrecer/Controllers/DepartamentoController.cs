﻿using evaAFPCrecer.Data;
using evaAFPCrecer.Models;
using Microsoft.AspNetCore.Mvc;

namespace evaAFPCrecer.Controllers
{
    public class DepartamentoController : Controller
    {
        private readonly IDepartamentos _iDepartamento;
        private int _idEmpresa;

        public DepartamentoController(IDepartamentos oDepartamento)
        {
            _iDepartamento = oDepartamento;
        }

        // GET: EmpresaController
        public IActionResult Index(int idEmpresa)
        {
            _idEmpresa = idEmpresa;
            ViewData["idEmpresa"] = idEmpresa;
            IEnumerable<Departamento> departamentos = _iDepartamento.ObtenerDepartamentos(idEmpresa);
            return View(departamentos);
        }

        // GET: EmpresaController/Details/5
        public IActionResult Details(int id, int idEmpresa)
        {
            Departamento departamento = _iDepartamento.ObtenerDepartamentobyId(id, idEmpresa);
            return View(departamento);
        }

        // GET: EmpresaController/Create
        public IActionResult Create()
        {
            //ViewData["idEmpresa"] = _idEmpresa;
            return View();
        }

        // POST: EmpresaController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Departamento departamento)
        {
            try
            {
                departamento.IdEmpresa = _idEmpresa;
                _iDepartamento.InsertDepartamento(departamento);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmpresaController/Edit/5
        public IActionResult Edit(int id, int idEmpresa)
        {
            Departamento departamento = _iDepartamento.ObtenerDepartamentobyId(id, idEmpresa);
            return View(departamento);
        }

        // POST: EmpresaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Departamento departamento)
        {
            try
            {
                _iDepartamento.UpdateDepartamento(departamento);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmpresaController/Delete/5
        public IActionResult Delete(int id, int idEmpresa)
        {
            Departamento departamento = _iDepartamento.ObtenerDepartamentobyId(id, idEmpresa);
            return View(departamento);
        }

        // POST: EmpresaController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(Departamento departamento)
        {
            try
            {
                _iDepartamento.DeleteDepartamento(departamento.Id, departamento.IdEmpresa);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
