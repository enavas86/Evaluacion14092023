﻿using evaAFPCrecer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using evaAFPCrecer.Data;

namespace evaAFPCrecer.Controllers
{
    public class EmpresaController : Controller
    {
        private readonly IEmpresas _iEmpresa;

        public EmpresaController(IEmpresas oEmpresa)
        {
            _iEmpresa = oEmpresa;
        }

        // GET: EmpresaController
        public IActionResult Index()
        {
            IEnumerable<Empresa> empresas = _iEmpresa.ObtenerEmpresas();
            return View(empresas);
        }

        // GET: EmpresaController/Details/5
        public IActionResult Details(int id)
        {
            Empresa empresa = _iEmpresa.ObtenerEmpresabyId(id);
            return View(empresa);
        }

        // GET: EmpresaController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EmpresaController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Empresa empresa)
        {
            try
            {
                _iEmpresa.InsertEmpresa(empresa);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmpresaController/Edit/5
        public IActionResult Edit(int id)
        {
            Empresa empresa = _iEmpresa.ObtenerEmpresabyId(id);
            return View(empresa);
        }

        // POST: EmpresaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Empresa empresa)
        {
            try
            {
                _iEmpresa.UpdateEmpresa(empresa);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmpresaController/Delete/5
        public IActionResult Delete(int id)
        {
            Empresa empresa = _iEmpresa.ObtenerEmpresabyId(id);
            return View(empresa);
        }

        // POST: EmpresaController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(Empresa empresa)
        {
            try
            {
                _iEmpresa.DeleteEmpresa(empresa.Id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
