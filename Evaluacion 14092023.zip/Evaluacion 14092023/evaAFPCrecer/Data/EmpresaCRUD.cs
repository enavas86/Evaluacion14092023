﻿using evaAFPCrecer.Models;
using System.Data;
using Dapper;

namespace evaAFPCrecer.Data
{
    public class EmpresaCRUD : IEmpresas
    {
        private readonly Conexion _conexion;

        public EmpresaCRUD(Conexion conexion)
        {
            _conexion = conexion;
        }

        public void DeleteEmpresa(int id)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", id, DbType.Int32);
                conexion.Execute("dbo.sp_DeleteEmpresa", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public void InsertEmpresa(Empresa objeto)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_nombre", objeto.Nombre, DbType.String);
                parametros.Add("@p_razonSocial", objeto.RazonSocial, DbType.String);
                parametros.Add("@p_fechaRegistro", objeto.FechaRegistro, DbType.DateTime);
                conexion.Execute("dbo.sp_InsertEmpresa", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<Empresa> ObtenerEmpresas()
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                return conexion.Query<Empresa>("dbo.sp_ListEmpresas", commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public Empresa ObtenerEmpresabyId(int id)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", id, DbType.Int32);
                return conexion.QueryFirstOrDefault<Empresa>("dbo.sp_GetEmpresa", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public void UpdateEmpresa(Empresa objeto)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", objeto.Id, DbType.Int32);
                parametros.Add("@p_nombre", objeto.Nombre, DbType.String);
                parametros.Add("@p_razonSocial", objeto.RazonSocial, DbType.String);
                parametros.Add("@p_fechaRegistro", objeto.FechaRegistro, DbType.DateTime);
                conexion.Execute("dbo.sp_UpdateEmpresa", parametros, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
