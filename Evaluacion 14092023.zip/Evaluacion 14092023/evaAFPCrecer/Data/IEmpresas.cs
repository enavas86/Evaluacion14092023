﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using evaAFPCrecer.Models;

namespace evaAFPCrecer.Data
{
    public interface IEmpresas
    {
        IEnumerable<Empresa> ObtenerEmpresas();

        Empresa ObtenerEmpresabyId(int id);

        void InsertEmpresa(Empresa objeto);

        void UpdateEmpresa(Empresa objeto);

        void DeleteEmpresa(int id);
    }
}
