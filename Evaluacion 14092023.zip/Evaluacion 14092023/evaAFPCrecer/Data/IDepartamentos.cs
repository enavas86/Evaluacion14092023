﻿using evaAFPCrecer.Models;

namespace evaAFPCrecer.Data
{
    public interface IDepartamentos
    {
        IEnumerable<Departamento> ObtenerDepartamentos(int idEmpresa);

        Departamento ObtenerDepartamentobyId(int id, int idEmpresa);

        void InsertDepartamento(Departamento objeto);

        void UpdateDepartamento(Departamento objeto);

        void DeleteDepartamento(int id, int idEmpresa);
    }
}
