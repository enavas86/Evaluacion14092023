﻿using evaAFPCrecer.Models;
using Dapper;
using System.Data;

namespace evaAFPCrecer.Data
{
    public class DepartamentoCRUD : IDepartamentos
    {
        private readonly Conexion _conexion;

        public DepartamentoCRUD(Conexion conexion)
        {
            _conexion = conexion;
        }

        public void DeleteDepartamento(int id, int idEmpresa)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", id, DbType.Int32);
                parametros.Add("@p_idEmpresa", idEmpresa, DbType.Int32);
                conexion.Execute("dbo.sp_DeleteDepartamento", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public void InsertDepartamento(Departamento objeto)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_idEmpresa", objeto.IdEmpresa, DbType.Int32);
                parametros.Add("@p_nombre", objeto.Nombre, DbType.String);
                parametros.Add("@p_numeroEmpleado", objeto.NumeroEmpleados, DbType.Int32);
                parametros.Add("@p_nivelOrganizacion", objeto.NivelOrganizacion, DbType.Int32);
                conexion.Execute("dbo.sp_InsertDepartamento", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<Departamento> ObtenerDepartamentos(int idEmpresa)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_idEmpresa", idEmpresa, DbType.Int32);
                return conexion.Query<Departamento>("dbo.sp_ListDepartamentos", parametros, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public Departamento ObtenerDepartamentobyId(int id, int idEmpresa)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", id, DbType.Int32);
                parametros.Add("@p_idEmpresa", idEmpresa, DbType.Int32);
                return conexion.QueryFirstOrDefault<Departamento>("dbo.sp_GetDepartamento", parametros, commandType: CommandType.StoredProcedure);
            }
        }

        public void UpdateDepartamento(Departamento objeto)
        {
            using (var conexion = _conexion.obtenerConexion())
            {
                var parametros = new DynamicParameters();
                parametros.Add("@p_id", objeto.Id, DbType.Int32);
                parametros.Add("@p_idEmpresa", objeto.IdEmpresa, DbType.Int32);
                parametros.Add("@p_nombre", objeto.Nombre, DbType.String);
                parametros.Add("@p_numeroEmpleado", objeto.NumeroEmpleados, DbType.Int32);
                parametros.Add("@p_nivelOrganizacion", objeto.NivelOrganizacion, DbType.Int32);
                conexion.Execute("dbo.sp_UpdateDepartamento", parametros, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
